#!/bin/bash
# Ensure MySQL is installed and in the system PATH
# Replace 'root' with the appropriate MySQL username and 'password' with the MySQL root password

echo "Creating database and tables..."
mysql -u root -ppassword -e "CREATE DATABASE IF NOT EXISTS library_management;"
mysql -u root -ppassword library_management < create.sql

echo "Setting up views..."
mysql -u root -ppassword library_management < views.sql

echo "Database setup completed."
