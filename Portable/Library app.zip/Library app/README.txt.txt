Instructions to Install and Run Library Management System:

1. Unzip the `distribution.zip` file to a directory of your choice.

2. Open a command prompt or terminal and navigate to the directory where you unzipped the files.

3. Run the database setup script:
   - On Windows: Run `setup_db.bat`
   - On Linux/Mac: Run `./setup_db.sh`

4. The script will create the database and tables, then create the views.

5. After the database is set up, run the application:
   - On Windows: Double-click `Library_Management_System.exe`

6. If you encounter any issues, ensure that MySQL is running on the machine.
